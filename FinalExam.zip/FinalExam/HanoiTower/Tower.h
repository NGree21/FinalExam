#ifndef TOWER_H
#define TOWER_H
#include <stack>
#include <iostream>
using namespace std;

template<typename T>
class Tower
{
private:
	int m_rings;
	stack<T> m_sourcePole;
	stack<T> m_destPole;
	stack<T> m_auxPole;

public:
	Tower();
	Tower(const int n);
	Tower(const Tower<T>& copy);
	Tower(Tower<T>&& move);
	~Tower();
	int getRings();
	void setRings(const int rings);
	Tower<T>& operator=(const Tower<T> copy);
	Tower<T>& operator=(Tower<T>&& move);
	void tower(const int rings, const stack<T> sourcePole, const stack<T> destPole, const stack<T> auxPole);
	void printTowers();
	void setStacks(stack<T> s, stack<T> d, stack<T> a);
};



#endif

template<typename T>
inline Tower<T>::Tower(): m_rings(0)
{
}

template<typename T>
inline Tower<T>::Tower(const int n) : m_rings(n)
{
}

template<typename T>
inline Tower<T>::Tower(const Tower<T>& copy): m_rings(copy.m_rings), m_sourcePole(copy.m_sourcePole), m_destPole(copy.m_destPole), m_auxPole(copy.m_auxPole)
{
}

template<typename T>
inline Tower<T>::Tower(Tower<T>&& move): m_rings(move.m_rings), m_sourcePole(move.m_sourcePole), m_destPole(move.m_destPole), m_auxPole(move.m_auxPole)
{
	move.m_rings = 0;
	move.m_sourcePole.empty();
	move.m_destPole.empty();
	move.m_auxPole.empty();
}

template<typename T>
inline Tower<T>::~Tower()
{
}

template<typename T>
inline int Tower<T>::getRings()
{
	return m_rings;
}

template<typename T>
inline void Tower<T>::setRings(const int rings)
{
	m_rings = rings;
}

template<typename T>
inline Tower<T>& Tower<T>::operator=(const Tower<T> copy)
{
	m_rings = copy.m_rings;
	m_sourcePole = copy.m_sourcePole;
	m_destPole = copy.m_sourcePole;
	m_auxPole = copy.m_auxPole;
}

template<typename T>
inline Tower<T>& Tower<T>::operator=(Tower<T>&& move)
{
	m_rings = move.m_rings;
	m_sourcePole = move.m_sourcePole;
	m_destPole = move.m_destPole;
	m_auxPole = move.m_auxPole;
	move.m_rings = 0;
	move.m_sourcePole.clear();
	move.m_destPole.clear();
	move.m_auxPole.clear();
}

template<typename T>
inline void Tower<T>::tower(const int rings, const stack<T> sourcePole, const stack<T> destPole, const stack<T> auxPole)
{
	int moves = pow(2, rings) - 1;
	m_rings = rings;
	m_sourcePole = sourcePole;
	if (moves % 2 == 0)
	{
		m_auxPole = destPole;
		m_destPole = auxPole;
	}
	if (rings == 1)
	{
	}
	else
	{
		for (int i = 1; i < moves; i++)
		{
			if (i % 3 == 1)
			{
				T temp1 = m_sourcePole.top();
				m_destPole.push(temp1);
				m_sourcePole.pop();
			}
			if (i % 3 == 2)
			{
				T temp2 = m_sourcePole.top();
				m_auxPole.push(temp2);
				m_sourcePole.pop();
			}
			if (i % 3 == 0)
			{
				T temp3 = m_auxPole.top();
				m_destPole.push(temp3);
				m_auxPole.pop();
			}
		}
	}
}

template<typename T>
inline void Tower<T>::printTowers()
{
	cout << "Number of Rings:\t" << m_rings << endl << endl;
	cout << "Source Pole: ";
	stack<T> temp = m_sourcePole;
	for (int i = 0; i < m_sourcePole.size(); i++)
	{
		T t = temp.top();
		cout << t << " ";
		temp.pop();
	}
	cout << endl << endl;

	temp = m_auxPole;
	cout << "Aux Pole: ";
	for (int j = 0; j < m_auxPole.size(); j++)
	{
		T t = temp.top();
		cout << t << " ";
		temp.pop();
	}
	cout << endl << endl;

	temp = m_destPole;
	cout << "Destination Pole: ";
	for (int k = 0; k < m_destPole.size(); k++)
	{
		T t = temp.top();
		cout << t << " ";
		temp.pop();
	}
	cout << endl << endl;
}

template<typename T>
inline void Tower<T>::setStacks(stack<T> s, stack<T> d, stack<T> a)
{
	m_sourcePole = s;
	m_destPole = d;
	m_auxPole = a;
}

