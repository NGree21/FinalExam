// https://www.codespeedy.com/program-for-tower-of-hanoi-using-stack-in-cpp/

#include <iostream>
using std::cout;
using std::cin;
using std::endl;
#include <stack>
#include "Tower.h"
using std::stack;
//#include <cmath>
void tower(int n, char source, char des, char via) {
    if (n == 1) {
        cout << "Moved the ring " << n << " from " << source << " to " << des << " via " << via << ".\n";

    }
    else {
        tower(n - 1, source, via, des);
        cout << "Moved the ring " << n << " from " << source << " to " << des << " via " << via << ".\n";
        tower(n - 1, via, des, source);
    }

}

int main()
{
    int rings;
    char source = 'A';
    char des = 'B';
    char via = 'C';
    cout << "Enter the number of rings : ";
    cin >> rings;
    stack<char> s; s.push(source);
    stack<char> d; d.push(des);
    stack<char> a; a.push(via);
    cout << "======Testing Tower=====" << endl;
    Tower<char>T1(rings);
    T1.setStacks(s, d, a);
    T1.tower(rings, s, d, a);
    T1.printTowers();
    if (testTower())
        cout << "*Test Passed*" << endl;
    return 0;
}


bool testTower()
{
    bool retval = true;
    stack<int> S = { 1,2,3,4,5 };
    stack<int> D;
    stack<int> A;
    cout << "Testing CTOR" << endl;
    Tower<int>T1(5);
    T1.setRings(S, D, A);
    if (T1.getRings() != 5)
        retval = false;
    cout << "Testing Copy Ctor" << endl;
    Tower<int>T2 = T1;
    if (T1.getRings() != T2.getRings())
        retval == false;
    return retval;
}