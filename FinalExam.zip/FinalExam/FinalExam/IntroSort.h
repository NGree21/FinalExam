#ifndef INTROSORT_H
#define INTROSORT_H

#include<iostream>
#include"Array.h"
#include"Exception.h"
#include <algorithm>


using namespace std;


template<typename T>
class IntroSort
{
private:
	Array<T> m_arr;
	int maxDepth;
public:
	IntroSort();
	IntroSort(Array<T> arr, int depth);
	~IntroSort();
	void sort(Array<T>& arr);
	void introSort(Array<T>& arr, int depth);
	void insertionSort(Array<T>& arr);
	int part(Array<T> arr, int low, int high);
	void swap(T* a, T* b);
	int* median(int* i, int* j, int* k);
};




template<typename T>
inline IntroSort<T>::IntroSort()
{
	m_arr = Array<T>();
	maxDepth = 0;
}

template<typename T>
inline IntroSort<T>::IntroSort(Array<T> arr, int depth)
{
	m_arr = arr;
	maxDepth = depth;
}

template<typename T>
inline IntroSort<T>::~IntroSort()
{
}

template<typename T>
inline void  IntroSort<T>::sort(Array<T> & arr)
{
	maxDepth = 2 * log(arr.GetLength() - arr.GetStartIndex());
	introSort(arr, maxDepth);

}

template<typename T>
inline void IntroSort<T>::introSort(Array<T> & arr, int depth)
{
	int n = arr.GetLength();
	int b = arr.GetStartIndex();
	int e = arr.GetLength();
	int* begin = &b;
	int* end = &e;
	if (n < 20)
	{
		insertionSort(arr);
		return;
	}
	if (depth == 0)
	{
		make_heap(arr.GetStartIndex(), arr.GetLength() + 1);
		sort_heap(arr.GetStartIndex(), arr.GetLength() + 1);
		return;
	}

	int* p = median(begin, (begin - arr.GetLength()/ 2), end);


	int* temp = p;
	p = end;
	end = temp;



	int* partPoint = part(arr, *begin, *end);;
	IntroSort(arr, depth - 1);
	IntroSort(arr, depth - 1);



	return;
}

template<typename T>
inline void IntroSort<T>::insertionSort(Array<T> & arr)
{
	for (int i = arr.GetStartIndex() + 1; i <= arr.GetLength(); i++)
	{
		T key = arr[i];
		int j = i - 1;
		while (j >= arr.GetStartIndex() && arr[j] > key)
		{
			arr[j + 1] = arr[j];
			j = j - 1;
		}
		arr[j + 1] = key;
	}
}

template<typename T>
inline int IntroSort<T>::part(Array<T> arr, int low, int high)
{
	int p = arr[high];
	int retval = (low - 1);

	for (int j = low; j <= high - 1; j++)
	{
		if (arr[j] <= p)
		{
			retval++;
			T temp = arr[retval];
			arr[retval] = arr[j];
			arr[j] = temp;
		}
	}
	T temp = arr[retval+1];
	arr[retval+1] = arr[high];
	arr[high] = temp;
	retval++;
	return retval;
}

template<typename T>
inline int* IntroSort<T>::median(int* i, int* j, int* k)
{
	if (*i < *j && *j < *k)
		return j;
	if (*i < *k && *k <= *j)
		return k;
	if (*j <= *i && *i < *k)
		return i;
	if (*j < *k && *k <= *i)
		return k;
	if (*k <= *i && *i < *j)
		return i;
	if (*k <= *j && *j <= *k)
		return j;
}

























#endif // !INTROSORT_H