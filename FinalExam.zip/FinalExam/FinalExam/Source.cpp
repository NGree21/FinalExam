#include <iostream>
#include "Array.h"
#include "Exception.h"
#include "IntroSort.h"
using std::cout; 
using std::endl;

int main()
{
    //Testing IntroSort


    cout << "======Testing IntroSort Function======" << endl;
    int arr[] = { 1,2,3,4,5,5,4,3,2,1 };
    Array<int> arr1;
    arr1.SetArr(arr);

    IntroSort<int> S1(arr1, 10);
    cout << "Original Array" << endl;
    for (int i = 0; i < 10; i++)
    {
        cout << arr[i] << " ";
    }
    cout << endl;

    S1.sort(arr1);

    cout << "Sorted Array" << endl;
    for (int i = 0; i < 10; i++)
    {
        cout << arr1[i] << " ";
    }
    cout << endl;

    return 0;
}