#ifndef ARRAY_H
#define ARRAY_H

#include <iostream>
#include <string>
#include "Exception.h"


using std::string;
using std::cout;
using std::endl;

template <typename T>
class Array
{
private:
	T* m_array;
	int m_start_index;
	int m_length;

public:
	Array();
	Array(const int length);
	Array(const int length, const int start_index);
	Array(const Array<T>& copy);
	Array(Array<T>&& copy);
	Array<T>& operator =(const Array<T>& rhs);
	Array<T>& operator =(Array<T>&& rhs);
	~Array();
	T& operator [](int index);
	int GetStartIndex();
	void SetStartIndex(const int start_index);
	int GetLength();
	void SetLength(const int length);
	void SetArr(T* arr);
	T* GetArr();

};

template<typename T>
inline Array<T>::Array() :m_array(nullptr), m_start_index(0), m_length(0)
{
}

template<typename T>
Array<T>::Array(const int length)// : m_array(nullptr), m_start_index(0)
{
	if (length < 0) {
		throw Exception("Length cant be Negative");
	}
	m_array = nullptr;
	m_start_index = 0;
	m_length = length;
	m_array = new T[m_length];
}

template<typename T>
inline Array<T>::Array(const int length, const int start_index)
{
	m_array = new T[length];
	m_start_index = start_index;
	m_length = length;
}

template<typename T>
inline Array<T>::Array(const Array<T>& copy)	//copy ctor
{
	m_length = copy.m_length;
	m_start_index = copy.m_start_index;
	m_array = new T[m_length];
	for (int i = m_start_index; i < m_length; i++)
	{
		m_array[i] = copy.m_array[i];
	}
}

template<typename T>
inline Array<T>::Array(Array<T>&& copy) : m_array(*copy.m_array), m_length(copy.m_length), m_start_index(copy.m_start_index)	//move ctor
{
	copy.m_array = nullptr;
	copy.m_length = 0;
	copy.m_start_index = 0;
}

template<typename T>
inline Array<T>& Array<T>::operator =(const Array<T>& rhs)
{
	
	if (this == &rhs)
		return *this;
	delete[] m_array;
	m_array = nullptr;
	auto arr = Array<T>{ rhs.m_length, rhs.m_start_index };
	for (int i = 0; i < rhs.m_length; i++)
	{
		arr[i] = rhs.m_array[i];
	}
	*this = std::move(arr);
		m_array = new T[rhs.m_length];
		m_length = rhs.m_length;
		m_start_index = rhs.m_start_index;
		for (int i = 0; i < m_length; i++) {
			m_array[i] = rhs.m_array[i];
		}
	return *this;
}

template <typename T>
inline Array<T>& Array<T>::operator =(Array<T>&& rhs) 
{

	*this = std::move(rhs);
	if (this == &rhs)
		return *this;

	delete[] m_array;
	m_array = nullptr;
	if (rhs.m_array != nullptr)
	{
		m_array = new T[rhs.m_length];
		m_length = rhs.m_length;
		for (int i = 0; i < m_length; i++) {
			m_array = rhs.m_array;
		}

	}
	return *this;
}

template<typename T>
inline int Array<T>::GetStartIndex()
{
	return m_start_index;
}

template<typename T>
inline int Array<T>::GetLength()
{
	return m_length;
}

template<typename T>
inline Array<T>::~Array()
{
	m_array = nullptr;
	m_length = 0;
	m_start_index = 0;
}

template<typename T>
inline T& Array<T>::operator[](const int index)	{
	int ind1 = index - m_start_index;
	if (ind1 >= m_length || index < 0) {
		Exception E("Index is out of bounds");
		throw E;
	}
	return m_array[ind1];
	
	
}

template<typename T>
void Array<T>::SetStartIndex(const int start_index)
{
	m_start_index = start_index;
}

template<typename T>
inline void Array<T>::SetLength(const int length)
{
	if (length < 0)
	{
		Exception E("Length is less than 0");
		throw E;
	}
	T *arr = new T[length];
	T* zero = new T{ 0 };
	for (int i = 0; i < length; i++)
	{
		if (i >= m_length)
		{
			arr[i] = zero[0];
		}
		else
		{
			arr[i] = m_array[i];
		}
	}
	m_length = length;
	//delete[] m_array;
	m_array = arr;
	

	
	
	

}
template<typename T>
inline void Array<T>::SetArr(T* arr)
{
	m_array = arr;
}
template<typename T>
inline T* Array<T>::GetArr()
{
	return m_array;
}
#endif