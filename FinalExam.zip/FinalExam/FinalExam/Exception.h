#ifndef EXCEPTION_H
#define EXCEPTION_H

#include <iostream>
#include<ostream>
#include<string>
#include <exception>
using std::ostream;
using std::string;


class Exception : virtual public std::exception
{
private:
	string m_msg;

public:
	Exception();
	~Exception();
	Exception(const string& msg);
	Exception(const Exception& copy);
	Exception(Exception&& copy);
	Exception& operator =(const Exception& rhs);
	Exception& operator =(Exception&& rhs);
	const string getMessage();
	void setMessage(const string msg);
	//friend ostream& operator <<(ostream& stream, const Exception& except);

};


inline Exception::Exception() : m_msg("")
{
}


inline Exception::~Exception()
{
}


inline Exception::Exception(const string& msg) : m_msg(msg)
{
}


inline Exception::Exception(const Exception& copy) : m_msg(copy.m_msg)
{
}

inline Exception::Exception(Exception&& copy) : m_msg(copy.m_msg)
{
	copy.m_msg = "";
}


inline Exception& Exception::operator=(const Exception& rhs)
{
	if (this == &rhs)
		return *this;

	m_msg = rhs.m_msg;
}


inline Exception& Exception::operator=(Exception&& rhs)
{
	if (this == &rhs)
	{
		rhs.m_msg = "";
		return *this;
	}

	m_msg = rhs.m_msg;
	rhs.m_msg = "";
}


inline const string Exception::getMessage()
{
	return m_msg;
}


inline void Exception::setMessage(const string msg)
{
	m_msg = msg;
}

//template <typename Y>
//inline ostream& operator <<(ostream& stream, const Exception& except) 
//{
//	stream << except.m_msg << std::endl;
//}

#endif